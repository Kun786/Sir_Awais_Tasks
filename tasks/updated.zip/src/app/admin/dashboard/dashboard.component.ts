import { Component, OnInit, ViewChild } from '@angular/core';



import {
  ApexAxisChartSeries,
  ApexChart,
  ChartComponent,
  ApexDataLabels,
  ApexPlotOptions,
  ApexYAxis,
  ApexLegend,
  ApexStroke,
  ApexXAxis,
  ApexFill,
  ApexTooltip,
  ApexTitleSubtitle,
  
} from "ng-apexcharts";


export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  yaxis: ApexYAxis;
  xaxis: ApexXAxis;
  fill: ApexFill;
  tooltip: ApexTooltip;
  stroke: ApexStroke;
  legend: ApexLegend;
  title:ApexTitleSubtitle;
  subtitle:ApexTitleSubtitle;


};

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  public menu:any;

  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;


  constructor() {



   }
public series:any;
public charts:any;
public titles="Last One Year";
  ngOnInit(): void {
  


    this.series= [
      {
        name: "New",
        data: [44, 55, 57, 56, 61, 58, 63, 60, 66]
      },
      {
        name: "Registered",
        data: [76, 85, 101, 98, 87, 105, 91, 114, 94]
      },
      {
        name: "Verified",
        data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
      }
    ];

    this.charts={
      type: "bar",
      height: 350
    }
  
  }

}

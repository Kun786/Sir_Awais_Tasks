import { Component, OnInit } from '@angular/core';
import { AbstractControl,FormBuilder,FormGroup,Validators} from '@angular/forms';
import { validateNotEmpty } from 'validation-utils';
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  form: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group(
      {
        fullname: ['', Validators.required],
        message: ['', Validators.required],
         
        email: ['', [Validators.required, Validators.email]],
   
     
      },
     
    );
  }

  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }

  onSubmit(): void {
    this.submitted = true;

    if (this.form.invalid) {
      return;
    }

    console.log(JSON.stringify(this.form.value, null, 2));
  }


}

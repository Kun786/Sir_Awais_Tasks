(function($) {

	"use strict";

	var fullHeight = function() {
		console.log("Toggling-onwidow chagne");

		$('.js-fullheight').css('height', $(window).height());
		$(window).resize(function(){
			$('.js-fullheight').css('height', $(window).height());
		});

	};
	fullHeight();

	$('#sidebarCollapse').on('click', function () {
		console.log("Toggling");
      $('#sidebar').toggleClass('active');
  });


  

})(jQuery);

function sideToggle(){
var element = document.getElementById("sidebar");
  element.classList.toggle("active");
}


function leftScroll(){

	var element = document.getElementById("slider");
	style = window.getComputedStyle(element),
	pad=style.getPropertyValue('padding-left');
  console.log(style.getPropertyValue('padding-left'));
  element.setAttribute("style","padding-left: '30px");
 
}


$('#recipeCarousel').carousel({
	interval: 10000
  });
  
  $('.carousel .carousel-item').each(function(){
	  var minPerSlide = 3;
	  var next = $(this).next();
	  if (!next.length) {
	  next = $(this).siblings(':first');
	  }
	  next.children(':first-child').clone().appendTo($(this));
	  
	  for (var i=0;i<minPerSlide;i++) {
		  next=next.next();
		  if (!next.length) {
			  next = $(this).siblings(':first');
			}
		  
		  next.children(':first-child').clone().appendTo($(this));
		}
  });
  







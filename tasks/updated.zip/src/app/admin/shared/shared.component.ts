import { Component, OnInit, ViewChild } from '@angular/core';
import  data from '../_adminFile/page_option_1.json'



import {
  ApexAxisChartSeries,
  ApexChart,
  ChartComponent,
  ApexDataLabels,
  ApexPlotOptions,
  ApexYAxis,
  ApexLegend,
  ApexStroke,
  ApexXAxis,
  ApexFill,
  ApexTooltip,
  ApexTitleSubtitle,
  
} from "ng-apexcharts";


export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  yaxis: ApexYAxis;
  xaxis: ApexXAxis;
  fill: ApexFill;
  tooltip: ApexTooltip;
  stroke: ApexStroke;
  legend: ApexLegend;
  title:ApexTitleSubtitle;
  subtitle:ApexTitleSubtitle;


};

@Component({
  selector: 'app-shared',
  templateUrl: './shared.component.html',
  styleUrls: ['./shared.component.scss']
})
export class SharedComponent implements OnInit {
  public menu:any;

  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;


  constructor() {



   }
public series:any;
public charts:any;
public titles="Last One Year";

public isDisable=true;
  ngOnInit(): void {
    console.log(data[1].pageOptions[0].menus);
    this.menu=data[1].pageOptions[0].menus;


    this.series= [
      {
        name: "New",
        data: [44, 55, 57, 56, 61, 58, 63, 60, 66]
      },
      {
        name: "Registered",
        data: [76, 85, 101, 98, 87, 105, 91, 114, 94]
      },
      {
        name: "Verified",
        data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
      }
    ];

    this.charts={
      type: "bar",
      height: 350
    },



    this.chartOptions = {
      series: [
        {
          name: "Net Profit",
          data: [44, 55, 57, 56, 61, 58, 63, 60, 66]
        },
        {
          name: "Revenue",
          data: [76, 85, 101, 98, 87, 105, 91, 114, 94]
        },
        {
          name: "Free Cash Flow",
          data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
        }
      ],
      chart: {
        type: "bar",
        height: 350
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "55%",
          //  endingShape: "rounded"
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        show: true,
        width: 2,
        colors: ["transparent"]
      },
      xaxis: {
        categories: [
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct"
        ]
      },
      yaxis: {
        title: {
          text: "$ (thousands)"
        }
      },
      fill: {
        opacity: 1
      },
      tooltip: {
        y: {
          formatter: function(val) {
            return "$ " + val + " thousands";
          }
        }
      }
    };
  
  }



  changeStatus(){

    let val=this.isDisable;
    if(val==true){
      this.isDisable=false;
    }
  }

  onChangeField(){
    this.isDisable=true;
  }


}

import { Component, OnInit } from '@angular/core';
import option from '../_file/option.json';
import { NotificationService } from '../services/notification.service';
import { AbstractControl,FormBuilder,FormGroup,Validators} from '@angular/forms';
import { validateNotEmpty } from 'validation-utils';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  form: FormGroup;
  submitted = false;
  email:string;
  password:string;
  isRegister = false;
  isLogin = false;
  pages:any;
  constructor(
  private notificationService : NotificationService,
  private formBuilder: FormBuilder,
private router:Router
  ) { }

  ngOnInit(): void {
    console.log(option[0].pageOptions[0].menus);
    this.pages=option[0].pageOptions[0].menus;

    this.form = this.formBuilder.group(
      {
        firstname: ['', Validators.required],
        lastname: ['', Validators.required],    
        email: ['', [Validators.required, Validators.email]],
       password: ['', Validators.required], 
      }, 
    );
  }
  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }
  onSubmit(): void {
    this.submitted = true;
    

    if (this.form.invalid) {
      return;
    }
    console.log(JSON.stringify(this.form.value, null, 2));
    this.notificationService.toastrSuccess(`Registration Successfully`, 'Registration');
  }
    
login(){
this.isLogin = !this.isLogin;
this.isRegister = false;
}
register(){
this.isRegister = !this.isRegister;
this.isLogin = false;
}
cancelReg(){
  this.isRegister = !this.isRegister;
}
cancelLog(){
  this.isLogin = !this.isLogin;
}

loginUser(){
     if(this.email=="admin@gmail.com" && this.password=="admin"){
    this.notificationService.toastrSuccess(`Admin Login Successfully`, 'Admin Login');
    this.router.navigate(['/admin/shared']);
     }else{
      this.notificationService.toastrWarning('Login Failed', 'Please try again');
     }
}


cancelAll(){
this.isRegister=false;
this.isLogin=false;
}
}

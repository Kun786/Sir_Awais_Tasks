import { Component, OnInit } from '@angular/core';
import option from '../_file/option.json';
import { NotificationService } from '../services/notification.service';
import { AbstractControl,FormBuilder,FormGroup,Validators} from '@angular/forms';
import { validateNotEmpty } from 'validation-utils';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
   pages:any;
   form: FormGroup;
   submitted = false;
   email:string;
   password:string;
   isRegister = false;
   isLogin = false;


   constructor(
   private notificationService : NotificationService,
   private formBuilder: FormBuilder){}


  ngOnInit() {
    console.log(option[0].pageOptions[0].menus)
    this.pages=option[0].pageOptions[0].menus;

    console.log(option[0].pageOptions[0].menus);
    this.pages=option[0].pageOptions[0].menus;

    this.form = this.formBuilder.group(
      {
        firstname: ['', Validators.required],
        lastname: ['', Validators.required],    
        email: ['', [Validators.required, Validators.email]],
       password: ['', Validators.required], 
      }, 
    );

  }


  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }
  onSubmit(): void {
    this.submitted = true;
    

    if (this.form.invalid) {
      return;
    }
    console.log(JSON.stringify(this.form.value, null, 2));
    this.notificationService.toastrSuccess(`Registration Successfully`, 'Registration');
  }
    
login(){
this.isLogin = !this.isLogin;
this.isRegister = false;
}
register(){
this.isRegister = !this.isRegister;
this.isLogin = false;
}
cancelReg(){
  this.isRegister = !this.isRegister;
}
cancelLog(){
  this.isLogin = !this.isLogin;
}

loginUser(){
     if(this.email=="admin@gmail.com" && this.password=="admin"){
    this.notificationService.toastrSuccess(`Admin Login Successfully`, 'Admin Login');
     }else{
      this.notificationService.toastrWarning('Login Failed', 'Please try again');
     }
}


cancelAll(){
this.isRegister=false;
this.isLogin=false;
}

}
